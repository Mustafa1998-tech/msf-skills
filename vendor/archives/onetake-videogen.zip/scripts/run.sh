#!/usr/bin/env bash
# Run a skill script with the right Python env.
#   run.sh <script.py> [args...]
# voiceover.py runs in the VoxCPM venv; everything else runs in the OneTake venv.
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
ONETAKE="${ONETAKE_HOME:-$HOME/OneTake}"
script="$1"; shift

# Git Bash on Windows: venvs keep Python in Scripts/, and Python needs native paths.
if [[ "${OS:-}" == Windows_NT ]]; then
  VENV_PY=Scripts/python.exe; SEP=';'
  native() { cygpath -w "$1"; }
else
  VENV_PY=bin/python; SEP=':'
  native() { printf '%s' "$1"; }
fi

if [[ "$(basename "$script")" == voiceover.py ]]; then
  PY="$ONETAKE/videogen/tts-venv/$VENV_PY"
else
  PY="$ONETAKE/.venv/$VENV_PY"
fi
if [[ ! -x "$PY" ]]; then
  echo "onetake-videogen: $PY not found. Run install.sh from $(dirname "$HERE") first." >&2
  exit 2
fi
if [[ "${OS:-}" == Windows_NT ]]; then
  export REMOTION_BROWSER_EXECUTABLE="${REMOTION_BROWSER_EXECUTABLE:-C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe}"
else
  SITE=$("$PY" -c 'import site; print(site.getsitepackages()[0])')
  # pip-installed cuBLAS/cuDNN for CTranslate2 (faster-whisper)
  export LD_LIBRARY_PATH="$SITE/nvidia/cublas/lib:$SITE/nvidia/cudnn/lib:${LD_LIBRARY_PATH:-}"
fi
# /tmp is often a RAM-backed tmpfs: keep temp media on disk
mkdir -p "$ONETAKE/storage/tmp"
export TMPDIR="$(native "$ONETAKE/storage/tmp")"
export ONETAKE_HOME="$(native "$ONETAKE")"
export PYTHONPATH="$(native "$ONETAKE")$SEP$(native "$HERE")${PYTHONPATH:+$SEP$PYTHONPATH}"
# Windows otherwise reads and writes text in a legacy code page, not UTF-8.
export PYTHONUTF8=1
cd "$ONETAKE"
exec "$PY" "$(native "$HERE/$(basename "$script")")" "$@"
