"""Shared helpers for the onetake-videogen scripts."""

import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path

SKILL_DIR = Path(__file__).resolve().parent.parent
ONETAKE = Path(os.environ.get("ONETAKE_HOME", Path.home() / "OneTake"))
FONTS_DIR = SKILL_DIR / "assets" / "fonts"
REMOTION_DIR = SKILL_DIR / "remotion"
# Windows only starts npx.cmd when given its full path.
NPX = shutil.which("npx") or "npx"

TARGET_W, TARGET_H, TARGET_FPS = 1280, 720, 60


def load_json(path):
    return json.loads(Path(path).read_text())


def save_json(obj, path):
    Path(path).write_text(json.dumps(obj, ensure_ascii=False, indent=1))


def probe(path):
    """Return duration, video size/fps and whether audio exists."""
    out = subprocess.run(
        ["ffprobe", "-v", "error", "-show_entries",
         "format=duration:stream=codec_type,width,height,avg_frame_rate",
         "-of", "json", str(path)],
        capture_output=True, text=True, check=True,
    ).stdout
    d = json.loads(out)
    info = {"duration": float(d["format"]["duration"]), "has_audio": False, "has_video": False}
    for s in d.get("streams", []):
        if s["codec_type"] == "video" and not info["has_video"]:
            num, den = (s.get("avg_frame_rate") or "0/1").split("/")
            info.update(has_video=True, width=s["width"], height=s["height"],
                        fps=float(num) / float(den) if float(den) else 0)
        elif s["codec_type"] == "audio":
            info["has_audio"] = True
    return info


def run(cmd, **kw):
    """Run a command, raising with the stderr tail on failure."""
    r = subprocess.run([str(c) for c in cmd], capture_output=True, text=True, **kw)
    if r.returncode != 0:
        raise RuntimeError(f"{cmd[0]} failed ({r.returncode}):\n{r.stderr[-3000:]}")
    return r


_held = []  # the Windows lock and job end when these handles close


def _cap_windows(mem, lock):
    """Take the render lock, then cap committed memory for this process and all its children."""
    import ctypes
    import msvcrt
    from ctypes import wintypes as w

    f = open(lock, "a+b")
    f.seek(0)
    waited = False
    while True:
        try:
            msvcrt.locking(f.fileno(), msvcrt.LK_NBLCK, 1)
            break
        except OSError:
            if not waited:
                print("another render is running; waiting for the lock", file=sys.stderr)
                waited = True
            time.sleep(2)

    class Basic(ctypes.Structure):
        _fields_ = [("PerProcessUserTimeLimit", ctypes.c_longlong), ("PerJobUserTimeLimit", ctypes.c_longlong),
                    ("LimitFlags", w.DWORD), ("MinimumWorkingSetSize", ctypes.c_size_t),
                    ("MaximumWorkingSetSize", ctypes.c_size_t), ("ActiveProcessLimit", w.DWORD),
                    ("Affinity", ctypes.c_size_t), ("PriorityClass", w.DWORD), ("SchedulingClass", w.DWORD)]

    class Extended(ctypes.Structure):
        _fields_ = [("BasicLimitInformation", Basic), ("IoInfo", ctypes.c_ulonglong * 6),
                    ("ProcessMemoryLimit", ctypes.c_size_t), ("JobMemoryLimit", ctypes.c_size_t),
                    ("PeakProcessMemoryUsed", ctypes.c_size_t), ("PeakJobMemoryUsed", ctypes.c_size_t)]

    k32 = ctypes.WinDLL("kernel32", use_last_error=True)
    k32.CreateJobObjectW.restype = w.HANDLE
    k32.CreateJobObjectW.argtypes = [ctypes.c_void_p, w.LPCWSTR]
    k32.SetInformationJobObject.argtypes = [w.HANDLE, ctypes.c_int, ctypes.c_void_p, w.DWORD]
    k32.GetCurrentProcess.restype = w.HANDLE
    k32.AssignProcessToJobObject.argtypes = [w.HANDLE, w.HANDLE]

    job = k32.CreateJobObjectW(None, None)
    limits = Extended()
    limits.BasicLimitInformation.LimitFlags = 0x200 | 0x2000  # JOB_MEMORY | KILL_ON_JOB_CLOSE
    limits.JobMemoryLimit = int(mem.rstrip("G")) << 30
    if not (job and k32.SetInformationJobObject(job, 9, ctypes.byref(limits), ctypes.sizeof(limits))
            and k32.AssignProcessToJobObject(job, k32.GetCurrentProcess())):
        raise ctypes.WinError(ctypes.get_last_error())
    _held.extend([f, job])


def ensure_capped(mem="6G", lock="/tmp/qb-render.lock"):
    """Run this script under a memory cap and a one-render-at-a-time lock (waits its turn)."""
    if os.environ.get("ONETAKE_CAPPED"):
        return
    if os.name == "nt":
        _cap_windows(mem, Path(tempfile.gettempdir()) / Path(lock).name)
        os.environ["ONETAKE_CAPPED"] = "1"
        return
    if not shutil.which("systemd-run") or not shutil.which("flock"):
        raise SystemExit("systemd-run and flock are required: renders must run capped, one at a time")
    busy = subprocess.run(["pgrep", "-af", "remotion render"], capture_output=True, text=True).stdout.strip()
    if busy:
        print("another render is running; waiting for the lock", file=sys.stderr)
    os.environ["ONETAKE_CAPPED"] = "1"
    os.execvp("systemd-run", ["systemd-run", "--user", "--scope", "-p", f"MemoryMax={mem}",
                              "-p", "MemorySwapMax=0", "--quiet", "flock", lock, sys.executable, *sys.argv])


def fmt_ts(sec):
    h, rem = divmod(sec, 3600)
    m, s = divmod(rem, 60)
    return f"{int(h):02d}:{int(m):02d}:{s:04.1f}"
